import boto3
import base64
import json
import uuid
from botocore.exceptions import ClientError

polly = boto3.client('polly')
s3 = boto3.client('s3')

def health(event, context):
    body = {
        "message": "Go Serverless v3.0! Your function executed successfully!",
        "input": event,
    }

    response = {"statusCode": 200, "body": json.dumps(body)}

    return response

def v1_description(event, context):
    body = {
        "message": "TTS api version 1."
    }

    response = {"statusCode": 200, "body": json.dumps(body)}

    return response

def v2_description(event, context):
    body = {
        "message": "TTS api version 2."
    }

    response = {"statusCode": 200, "body": json.dumps(body)}

    return response

def v1_tts_description(event, context):
    try:
        # Extract the phrase from the event body
        dados = json.loads(event['body'])
        phrase = dados["phrase"]

        # Use Amazon Polly to synthesize speech
        
        response = polly.synthesize_speech(
            Text=phrase,
            OutputFormat='mp3',
            VoiceId='Joanna'
        )
        file = response['AudioStream']
        id_unico = str(uuid.uuid4())
        nome = f"{id_unico}.mp3" 

        acl='public-read'
        s3.upload_fileobj(file,"my-bucket-for-audios",nome,ExtraArgs={'ACL': 'bucket-owner-full-control'})
        
        # Generate a placeholder audio URL (replace with actual generation logic)
        audio_url = "https://my-bucket-for-audios.s3.amazonaws.com/"+nome  # Placeholder

        # Generate a placeholder creation date (replace with actual generation logic)
        created_audio = "01/02/2023"  # Placeholder

        # Prepare the response body
        body = {
            "received_phrase": phrase,
            "url_to_audio": audio_url,
            "created_audio": created_audio
        }

        return {
            "statusCode": 200,
            "body": json.dumps({"body": body})
        }
    except (ClientError, json.JSONDecodeError) as error:
        # Handle potential errors gracefully
        error_message = f"An error occurred: {str(error)}"
        return {
            "statusCode": 500,
            "body": json.dumps({"error": error_message})
        }

def v2_tts_description(event, context):
    """ received_data = event['queryStringParameters']
    s = received_data

    body =   {
    "received_phrase": "converta esse texto para áudio = "+s,
    "url_to_audio": "https://meu-buckect/audio-xyz.mp3",
    "created_audio": "02-02-2023 17:00:00"
  } """
    response = {"statusCode": 200, "body": json.dumps(event)}
    return response